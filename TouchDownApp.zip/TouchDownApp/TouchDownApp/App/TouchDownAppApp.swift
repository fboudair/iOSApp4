//
//  TouchDownAppApp.swift
//  TouchDownApp
//
//  Created by Louise Rennick on 2025-03-03.
//

import SwiftUI

@main
struct TouchDownAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
